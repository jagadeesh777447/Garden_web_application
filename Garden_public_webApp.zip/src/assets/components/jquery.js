$(document).ready(function () {
    alert("ok");
    console.log("Hello World!");
  });