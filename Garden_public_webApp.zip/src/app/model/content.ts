export class Content{
    About: any;
    address: any;
    CompanyName: any;
    Email: any;
    Image: any;
    OwnerName: any;
    Phone: any;
    Vision: any;
    CreatedBy: any;
    CreatedOn: any;
    UpdatedOn: any;
    UpdatedBy: any;
    SettingsId: any;
}