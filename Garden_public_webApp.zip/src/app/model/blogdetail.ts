export class BlogDetail{
    CategoryName: any;
    CreatedDate: any;
    Image: any;
    Keywords: any;
    LongDescription: any;
    Metatags : any;
    PublishDate: any;
    SEOTitle: any;
    ShortDescription: any;
    title: any;
    displayComments: any;
    commentLength: any;
}