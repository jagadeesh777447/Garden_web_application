export class ProductDetail{
    title: any;
    data: any;
    imageUrl: any;
    Item: any;
    Image: any;
    categoryName: any;
    ShortDescription: any;
    SEOKeywords: any;
    LongDescription: any;
    RelatedProducts: any;
    htmlDescription: string ;
    productId: any;
    TeluguName: any;
    sizelist: any;
}